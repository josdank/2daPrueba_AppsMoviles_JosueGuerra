export type ChatMessage = {
  id: string;
  contratacion_id: string;
  sender_id: string;
  contenido: string;
  created_at: string;
};
