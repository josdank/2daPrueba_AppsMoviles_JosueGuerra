export const money = (v: number) => `$${v.toFixed(2)}/mes`;
