import React from 'react';
import { Card, Text, Button } from 'react-native-paper';
import { Image } from 'expo-image';
import { View, StyleSheet } from 'react-native';

export default function PlanCard({ plan, onPress, actionLabel, onAction }: any) {
  return (
    <Card style={styles.card} onPress={onPress}>
      {plan.imagen_url ? (
        <Image source={{ uri: plan.imagen_url }} style={styles.image} contentFit="cover" />
      ) : (
        <View style={styles.fallbackImage} />
      )}

      <Card.Content style={styles.content}>
        <Text variant="titleMedium" style={styles.title}>{plan.nombre_comercial}</Text>
        <View style={styles.row}>
          <Text variant="bodyLarge" style={styles.price}>${plan.precio}</Text>
          <Text variant="bodySmall" style={styles.segment}>{plan.segmento}</Text>
        </View>
        <Text variant="bodySmall" numberOfLines={2} style={styles.desc}>
          {plan.descripcion_corta || ''}
        </Text>
      </Card.Content>

      {actionLabel && (
        <Card.Actions style={styles.actions}>
          <Button mode="outlined" onPress={onAction} style={styles.actionBtn}>
            {actionLabel}
          </Button>
        </Card.Actions>
      )}
    </Card>
  );
}

const styles = StyleSheet.create({
  card: {
    marginVertical: 10,
    borderRadius: 12,
    overflow: 'hidden',
    marginHorizontal: 8,
    backgroundColor: '#fff',
    elevation: 4,
  },
  image: { width: '100%', height: 150 },
  fallbackImage: { width: '100%', height: 150, backgroundColor: '#eee' },
  content: { paddingVertical: 12 },
  title: { marginBottom: 6 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontWeight: '700' },
  segment: { fontSize: 12, color: '#777' },
  desc: { marginTop: 6, color: '#666' },
  actions: { justifyContent: 'flex-end', padding: 12 },
  actionBtn: { borderRadius: 8, paddingHorizontal: 16 },
});